/*
 * meio q uma gambi...mas ta certo
 */
package LFuzzyLibrary;

import TemperatureConsumptionFC.FiniteInputLinguisticImplC;
import TemperatureConsumptionFC.FiniteInputLinguisticImplT;
import TemperatureConsumptionFC.FiniteOutputLinguisticImpl;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;

/**
 * @author msantosteixeira
 */
public class CompositionTC<A, B, C, L> {

    private Finite<A> finiteA;
    private Finite<B> finiteB;
    private Finite<C> finiteC;

    public CompositionTC(Finite<A> finiteA, Finite<B> finiteB, Finite<C> finiteC) {
        this.finiteA = finiteA;
        this.finiteB = finiteB;
        this.finiteC = finiteC;
    }

    public LRel<A, C, L> composition(HeytA<L> algebra, LRel<A, B, L> param1, LRel<B, C, L> param2, GenericComposition<L> genComp) {

        Hashtable<Pair<A, C>, L> newTable = new Hashtable();
        //For all B values

        for (A valueA : finiteA.getFiniteList()) {//21,100
            for (C valueC : finiteC.getFiniteList()) {//NC
                L res = algebra.bot();
                for (B valueB : finiteB.getFiniteList()) {//OT,OC

                    //
                    Pair<A, B> key1 = new Pair(valueA, valueB);
                    Pair<B, C> key2 = new Pair(valueB, valueC);

//                    Pair a = (Pair) key1.getFirst();//21,100
//                    Pair b = (Pair) key1.getSecond();//ot,oc
//                    if (a.getFirst().equals(21) && a.getSecond().equals(180)) {//<< && valueC.equals(FiniteOutputLinguisticImpl.PB)) {
                     
                        Pair<Float, Float> c = (Pair) param1.getValue(key1);
                        if (param1.getTable().containsKey(key1) && param2.getTable().containsKey(key2)) {//21,100 e OT,OC  && OT,OC,NC  so entra nos q tem regra

                            //res = join ( p1 meet p2)
                            // && b.getFirst().equals(FiniteInputLinguisticImplT.LC)
                            // && b.getSecond().equals(FiniteInputLinguisticImplC.LL)){       
                            //System.out.println(b.getFirst() + "-" + b.getSecond() + "--" + valueC + "--" + c.getFirst() + " : " + c.getSecond());

                            if (c.getFirst() > 0.0f && c.getSecond() > 0.0f) {//pois a regra so pode ser acionada se tiver valor nos 2
                                res = algebra.join(res, algebra.meet(param1.getValue(key1), param2.getValue(key2)));
                            }
                        }
                    //}
                }

//                Pair a1 = (Pair) valueA;//21,100
//                if (a1.getFirst().equals(21) && a1.getSecond().equals(210)) {
//                    Pair c = (Pair) res;
//                     System.out.println(valueC+"--"+c.getFirst()+":"+c.getSecond());
//                }
                newTable.put(new Pair(valueA, valueC), res);
//                if(valueC.equals(FiniteOutputLinguisticImpl.PB))
//                break;
            }
        }

        //Create new LRel with the new table
        LRel<A, C, L> lrel = new LRel();
        lrel.setTable(newTable);
        return lrel;
    }

    public LSet<A, L> toLSet(LRel<FiniteUnit, A, L> lRelObject) {
        Hashtable<A, L> newTable = new Hashtable();

        Set<Pair<FiniteUnit, A>> keys = lRelObject.getTable().keySet();
        Iterator<Pair<FiniteUnit, A>> itr = keys.iterator();

        //Iterate through this list, adding only the second value to the hashtable
        while (itr.hasNext()) {
            Pair<FiniteUnit, A> key = itr.next();
            newTable.put(key.getSecond(), lRelObject.getValue(key));
        }

        //Create new LSet with the a table containing A values
        LSet<A, L> newLSet = new LSet(newTable);
        return newLSet;
    }

}
