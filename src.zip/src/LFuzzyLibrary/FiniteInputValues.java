package LFuzzyLibrary;

/**
 *
 * @author Milene
 */
public interface FiniteInputValues<A> extends Finite<A>{
    
}
