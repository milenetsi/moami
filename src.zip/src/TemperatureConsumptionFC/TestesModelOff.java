/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TemperatureConsumptionFC;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Milene
 */
public class TestesModelOff {

    private DataHandler dh;

    public TestesModelOff() {
        this.dh = new DataHandler(new Settings());
    }
    
    public static void main(String[] argv) {
        TestesModelOff d = new TestesModelOff();
        d.threadMoAmI();
    }

    private void threadMoAmI() {

        //Thread that runs the controller
        ScheduledExecutorService executorFC = Executors.newSingleThreadScheduledExecutor();
        Runnable periodicTaskFC = new Runnable() {
            public void run() {
                try {
                    //
                    System.out.println("*************************************\n");

                    Float temperature = dh.getTemperatureFromSensor();
                    Float consumption = dh.getConsumption();
                    Integer temp = (Integer) Math.round(temperature);
                    Integer cons = (Integer) Math.round(consumption);

                    try {
                        BufferedWriter bw = new BufferedWriter(new FileWriter(new File("finalResultsMofdelOff.txt"), true));
                        //temp,cons,time
                        bw.write(temp + "-" + cons + " : " + LocalDateTime.now());
                        System.out.println(temp + "-" + cons + " : " + LocalDateTime.now());
                        bw.newLine();
                        bw.close();
                    } catch (IOException ex) {
                        Logger.getLogger(SimulatorNew.class.getName()).log(Level.SEVERE, null, ex);
                    }

                } catch (Exception e) {
                    System.out.println("exception " + e.getMessage());
                }
            }
        };
        executorFC.scheduleAtFixedRate(periodicTaskFC, 0, 10, TimeUnit.MINUTES);
    }
}
