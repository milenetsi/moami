/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TemperatureConsumptionFC;

import LFuzzyLibrary.FiniteInputLinguistic;
import LFuzzyLibrary.FiniteOutputLinguistic;
import LFuzzyLibrary.LRel;
import LFuzzyLibrary.Pair;
import LFuzzyLibrary.RulesBase;
import java.util.Hashtable;

/**
 * @author Milene
 */
public class RulesBaseImpl implements RulesBase {

    /**
     * 
     * @return FiniteInputLinguistic,FiniteOutputLinguistic, F,F
     */
    public LRel<FiniteInputLinguistic, FiniteOutputLinguistic, Pair<Float, Float>> getRulesBase() {

        Hashtable<Pair<FiniteInputLinguistic, FiniteOutputLinguistic>, Pair<Float, Float>> newTable = new Hashtable();

        //Contains list of all possible pairs of linguistic input
        FiniteInputLinguisticImplPair fILP = new FiniteInputLinguisticImplPair();
        //FiniteInputLinguisticImplPair
        for (Pair<FiniteInputLinguisticImplT, FiniteInputLinguisticImplC> fl : fILP.getFiniteList()) {
            //OT
            if (fl.getFirst().equals(FiniteInputLinguisticImplT.OT)) {
                if (fl.getSecond().equals(FiniteInputLinguisticImplC.OC)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NC), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.SH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PS), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.SL)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NC), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.LH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PS), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.LL)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NC), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.TH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PS), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.TL)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NC), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.MH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.AL), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.ML)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NC), new Pair(1.0f, 1.0f));
                }
            }
            //SW
            else if (fl.getFirst().equals(FiniteInputLinguisticImplT.SW)) {
                if (fl.getSecond().equals(FiniteInputLinguisticImplC.OC)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NS), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.SH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NC), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.SL)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NS), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.LH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NS), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.LL)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NS), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.TH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NC), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.TL)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NS), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.MH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.AL), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.ML)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NS), new Pair(1.0f, 1.0f));
                }
            }
            //SC
            else if (fl.getFirst().equals(FiniteInputLinguisticImplT.SC)) {
                if (fl.getSecond().equals(FiniteInputLinguisticImplC.OC)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PS), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.SH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NC), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.SL)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PS), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.LH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PS), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.LL)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PS), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.TH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PS), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.TL)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PS), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.MH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.AL), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.ML)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PS), new Pair(1.0f, 1.0f));
                }
            }
            //LW
            else if (fl.getFirst().equals(FiniteInputLinguisticImplT.LW)) {
                if (fl.getSecond().equals(FiniteInputLinguisticImplC.OC)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NS), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.SH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NS), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.SL)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NS), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.LH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NC), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.LL)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NM), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.TH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NC), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.TL)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NM), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.MH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.AL), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.ML)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NM), new Pair(1.0f, 1.0f));
                }
            }
            //LC
            else if (fl.getFirst().equals(FiniteInputLinguisticImplT.LC)) {
                if (fl.getSecond().equals(FiniteInputLinguisticImplC.OC)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PS), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.SH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PS), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.SL)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PS), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.LH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PS), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.LL)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PS), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.TH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PS), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.TL)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PS), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.MH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.AL), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.ML)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PM), new Pair(1.0f, 1.0f));
                }
            }
            //TW
            else if (fl.getFirst().equals(FiniteInputLinguisticImplT.TW)) {
                if (fl.getSecond().equals(FiniteInputLinguisticImplC.OC)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NM), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.SH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NS), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.SL)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NM), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.LH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NS), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.LL)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NM), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.TH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NC), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.TL)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NM), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.MH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.AL), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.ML)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NB), new Pair(1.0f, 1.0f));
                }
            }
            //TC
            else if (fl.getFirst().equals(FiniteInputLinguisticImplT.TC)) {
                if (fl.getSecond().equals(FiniteInputLinguisticImplC.OC)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PM), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.SH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PM), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.SL)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PM), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.LH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PM), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.LL)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PB), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.TH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PM), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.TL)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PM), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.MH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.AL), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.ML)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PB), new Pair(1.0f, 1.0f));
                }
            }
            //MW
            else if (fl.getFirst().equals(FiniteInputLinguisticImplT.MW)) {
                if (fl.getSecond().equals(FiniteInputLinguisticImplC.OC)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NM), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.SH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NS), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.SL)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NM), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.LH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NS), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.LL)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NM), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.TH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NS), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.TL)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NM), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.MH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.AL), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.ML)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.NB), new Pair(1.0f, 1.0f));
                }
            }
            //MC
            else if (fl.getFirst().equals(FiniteInputLinguisticImplT.MC)) {
                if (fl.getSecond().equals(FiniteInputLinguisticImplC.OC)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PB), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.SH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PB), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.SL)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PB), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.LH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PB), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.LL)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PB), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.TH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PB), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.TL)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PB), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.MH)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.AL), new Pair(1.0f, 1.0f));
                } else if (fl.getSecond().equals(FiniteInputLinguisticImplC.ML)) {
                    newTable.put(new Pair(fl, FiniteOutputLinguisticImpl.PB), new Pair(1.0f, 1.0f));
                }
            }
        }

        LRel<FiniteInputLinguistic, FiniteOutputLinguistic, Pair<Float, Float>> lrelResult = new LRel();
        lrelResult.setTable(newTable);
        return lrelResult;
    }

}
