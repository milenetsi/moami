/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package moamiapp;

import java.util.List;

/**
 *
 * @author Milene
 */
public abstract class ContextoInteresse {

    private List<SemanticRule> semanticRules;
    private Problem problema;

    public ContextoInteresse() {
    }

    public Problem getProblema() {
        return problema;
    }

    public void setProblema(Problem problema) {
        this.problema = problema;
    }
    
    public List<SemanticRule> getSemanticRules() {
        return semanticRules;
    }

    public void setSemanticRules(List<SemanticRule> semanticRules) {
        this.semanticRules = semanticRules;
    }

}
