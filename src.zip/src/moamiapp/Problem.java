/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package moamiapp;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Milene
 */
public class Problem<A> {
    
    private List<Objective<A>> objectives;

    public Problem() {
        this.objectives = new ArrayList();
    }    

    public List<Objective<A>> getObjectives() {
        return objectives;
    }

    public void setObjectives(List<Objective<A>> objectives) {
        this.objectives = objectives;
    }
    
    
    
}
