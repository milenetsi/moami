/**
 * MultiObjectivity in AmI
 * Masters Degree in Computer Science - UFSM
 *
 * @author Milene S. Teixeira (Teixeira, M.S.)
 */
package moamiappTC;

import TemperatureConsumptionFC.Settings;
import java.util.ArrayList;
import java.util.List;
import moamiapp.ContextoInteresse;
import moamiapp.Objective;
import moamiapp.SemanticRule;
import moamiapp.Item;

/**
 *
 * @author Milene
 */
public class ContextoInteresseImpl extends ContextoInteresse {

    private TomadaInteligente TomadaInteligenteX;//<<

    public ContextoInteresseImpl() {
        this.setSemanticRules(generateSemanticRulesList());
    }

    public TomadaInteligente getTomadaInteligente() {
        return TomadaInteligenteX;//<<
    }

    public ProblemImpl getProblemaImp() {
        return (ProblemImpl) this.getProblema();
    }

    public List<SemanticRule> generateSemanticRulesList() {
        List srList = new ArrayList<SemanticRule>();
        Settings s = new Settings();

        //Entidades
        Item Escritorio = new Item("Escritorio");
        Item ArcondicionadoX = new Item("ArcondicionadoX");
        Item Usuario = new Item("Usuario");
        this.setProblema(new ProblemImpl(s));

        //Tomada
        Item sTemp = new Item("DHT11");//temp
        Item sCons = new Item("SCT01320A");//corrente
        Item stensao = new Item("tensao");
        Item sinfravermelho = new Item("infravermelho");
        List<Item> sensores = new ArrayList();
        sensores.add(sTemp);
        sensores.add(sCons);
        sensores.add(stensao);
        sensores.add(sinfravermelho);
        this.TomadaInteligenteX = new TomadaInteligente("TomadaInteligenteX", sensores, s);

        //Regras//////
        SemanticRule sr1 = new SemanticRule<Item, Item>(Escritorio, ArcondicionadoX, "tem") {
            @Override
            public Boolean predicate(Item entitySubject, Item entityObject) {
                return true;
            }
        };
        srList.add(sr1);

        SemanticRule sr2 = new SemanticRule<Item, Item>(Escritorio, TomadaInteligenteX, "tem") {
            @Override
            public Boolean predicate(Item entitySubject, Item entityObject) {
                return true;
            }
        };
        srList.add(sr2);

        SemanticRule sr3 = new SemanticRule<Item, Item>(Usuario, Escritorio, "estaLocalizado") {
            @Override
            public Boolean predicate(Item entitySubject, Item entityObject) {
                return true;
            }
        };
        srList.add(sr3);

        SemanticRule sr4 = new SemanticRule<Item, Item>(ArcondicionadoX, TomadaInteligenteX, "estaLigadoA") {
            @Override
            public Boolean predicate(Item entitySubject, Item entityObject) {
                return true;//<<meio sem proposito
            }
        };
        srList.add(sr4);

        return srList;
    }

}
