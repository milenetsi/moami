/**
 * MultiObjectivity in AmI
 * Masters Degree in Computer Science - UFSM
 *
 * @author Milene S. Teixeira (Teixeira, M.S.)
 */
package moamiappTC;

import LFuzzyLibrary.Pair;
import java.util.ArrayList;
import java.util.List;
import moamiapp.Event;
import moamiapp.Item;
import moamiapp.SemanticRule;

/**
 *
 * @author Milene
 */
public class Ev2 extends Event<List<List<Pair<Integer, Float>>>> {

    private ContextoInteresseImpl cI;
    private List<Pair<Integer, Float>> optimalConsInterval;
    private List<Pair<Integer, Float>> optimalTempInterval;

    public Ev2(String name, ContextoInteresseImpl cI) {
        super(name);

        this.cI = cI;
        this.optimalTempInterval = cI.getProblemaImp().getObjectivesImpl().get(0).getIntervaloAdequado();
        this.optimalConsInterval = cI.getProblemaImp().getObjectivesImpl().get(1).getIntervaloAdequado();

        List srList = new ArrayList<SemanticRule>();
        SemanticRule sr1 = new SemanticRule<Item, Item>(new Item("ValorConsumoDeEnergiaX"), new Item("ConsumoDeEnergiaX"), "temValorColetado") {
            @Override
            public Boolean predicate(Item entitySubject, Item entityObject) {
                if (cI.getProblemaImp().getObjectivesImpl().get(1).getValue() != null) {
                    return true;
                }
                return false;
            }
        };
        srList.add(sr1);

        SemanticRule sr2 = new SemanticRule<Item, Item>(new Item("ValorTemperaturaX"), new Item("TemperaturaX"), "temValorColetado") {
            @Override
            public Boolean predicate(Item entitySubject, Item entityObject) {
                if (cI.getProblemaImp().getObjectivesImpl().get(0).getValue() != null) {
                    return true;
                }
                return false;
            }
        };
        srList.add(sr2);

        this.setSemanticRules(srList);
    }

    @Override
    public List<List<Pair<Integer, Float>>> patternOfRecognition() {
        List l = new ArrayList<List<Integer>>();
        l.add(optimalTempInterval);
        l.add(optimalConsInterval);
        return l;
    }

    public Boolean isOn() {
        //If the value of the objective is not in the expected interval, then the MO reasoning process should start
        boolean valueReadIsFine = false;

        //Check if temperature presents an accepted value
        ObjectiveImpl oTemp = this.cI.getProblemaImp().getObjectivesImpl().get(0);
        if (oTemp.getName().equals("temperature")) {
            for (Pair<Integer, Float> val : optimalTempInterval) {
                if (val.getFirst().equals(oTemp.getValue())) {
                    valueReadIsFine = true;//Value read is within the accepted interval
                    break;
                }
            }
        }

        //Temperature was ok, now let's check if concumption is fine
        if (valueReadIsFine) {
            ObjectiveImpl oCons = this.cI.getProblemaImp().getObjectivesImpl().get(1);
            if (oCons.getName().equals("consumption")) {
                for (Pair<Integer, Float> val : optimalConsInterval) {
                    if (oCons.getValue() <= val.getFirst()) {
                        if (valueReadIsFine) {
                            //Both are fine!
                            return true;//event is on
                        }

                        return false;
                    }
                }
            }
        }

        return false;
    }

}
