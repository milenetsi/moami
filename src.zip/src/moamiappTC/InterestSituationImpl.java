/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package moamiappTC;

import LFuzzyLibrary.Pair;
import java.util.ArrayList;
import java.util.List;
import moamiapp.Event;
import moamiapp.InterestSituation;

/**
 *
 * @author Milene
 */
public class InterestSituationImpl extends InterestSituation {

    private ContextoInteresseImpl cI;

    public InterestSituationImpl(String name, ContextoInteresseImpl cI) {
        super(name);
        
        this.cI = cI;

        //Ie
        List initialEventsList = new ArrayList<Event>();
        initialEventsList.add(new Ev1("ev1", cI));

        //Set values
        this.setValues(initialEventsList, new Ev2("ev2", cI));
    }

    @Override
    public Boolean situationOn() {
        Ev1 ev1 = (Ev1) this.getInitialEvents().get(0);
        return ev1.isOn();
    }

    @Override
    public void setValues(List<Event> initialEvents, Event finalEvent) {
        this.setInitialEvents(initialEvents);
        this.setFinalEvent(finalEvent);
    }
}
