/**
 * MultiObjectivity in AmI
 * Masters Degree in Computer Science - UFSM
 *
 * @author Milene S. Teixeira (Teixeira, M.S.)
 */
package moamiappTC;

import LFuzzyLibrary.Pair;
import LFuzzyLibrary.Sum;
import TemperatureConsumptionFC.FiniteSum;
import java.util.ArrayList;
import java.util.List;
import moamiapp.Event;
import moamiapp.Item;
import moamiapp.SemanticRule;

/**
 *
 * @author Milene
 */
public class Ev3 extends Event<List<Sum>> {

    private ContextoInteresseImpl cI;
    private Sum outputValue;

    public Ev3(String name, ContextoInteresseImpl cI, Sum outputValue) {
        super(name);

        this.outputValue = outputValue;
        this.cI = cI;

        List srList = new ArrayList<SemanticRule>();
        SemanticRule sr1 = new SemanticRule<Item, Item>(new Item("LFC"), new Item("ValorConfiguracao"), "temSaida") {
            @Override
            public Boolean predicate(Item entitySubject, Item entityObject) {
                if (outputValue != null) {
                    return true;
                }
                return false;
            }
        };
        srList.add(sr1);

        this.setSemanticRules(srList);
    }

    @Override
    public List<Sum> patternOfRecognition() {
        return new FiniteSum().getFiniteList();
    }

    public Boolean isOn() {

        for (Sum val : new FiniteSum().getFiniteList()) {
            if (val.equals(this.outputValue)) {
                return true;
            }
        }

        return false;
    }

}
