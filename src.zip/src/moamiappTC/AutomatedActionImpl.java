/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package moamiappTC;

import LFuzzyLibrary.Sum;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import moamiapp.AutomatedAction;
import moamiapp.CurrentSituation;
import moamiapp.SemanticRule;
import moamiapp.Service;

/**
 *
 * @author Milene
 */
public class AutomatedActionImpl extends AutomatedAction<Sum> {

    private TomadaInteligente TomadaInteligenteX;//<<

    public AutomatedActionImpl(String name, ContextoInteresseImpl cI) {
        super(name, cI);
        this.TomadaInteligenteX = cI.getTomadaInteligente();
    }

    @Override
    public void generateValues() {
        //Preconditions
        List srListPreconditions = new ArrayList<CurrentSituation>();

        CurrentSituation sitPrecond = new CurrentSituation("Decisão foi tomada", new Ev1("ev1", (ContextoInteresseImpl)this.getcI()), new Ev3("ev3", (ContextoInteresseImpl)this.getcI(), this.getInput())) {
            @Override
            public Boolean situationOn() {
                if(this.getFinalEvent().isOn()){
                    return true;
                }
                return false;
            }
        };
        srListPreconditions.add(sitPrecond);
        
        //Services
        Hashtable<Integer, Service<Sum>> servicesList = new Hashtable();
        servicesList.put(0, this.TomadaInteligenteX.getService());

        this.setValues(srListPreconditions, servicesList);
    }

    @Override
    public void setValues(List<CurrentSituation> preconditions, Hashtable<Integer, Service<Sum>> services) {
        this.setPreconditions(preconditions);
        this.setServices(services);
    }

}
