/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package moamiappTC;

import LFuzzyLibrary.FiniteInputValues;
import LFuzzyLibrary.HeytA;
import LFuzzyLibrary.HeytAFloat;
import LFuzzyLibrary.Pair;
import TemperatureConsumptionFC.FiniteInputValuesImplC;
import TemperatureConsumptionFC.FiniteInputValuesImplT;
import TemperatureConsumptionFC.Settings;
import java.util.ArrayList;
import java.util.List;
import moamiapp.Objective;
import moamiapp.Problem;

/**
 *
 * @author Milene
 */
public class ProblemImpl extends Problem {

    public ProblemImpl(Settings s) {
        super();

        Objective obj1 = new ObjectiveImpl("Conforto termico", calcInterval(new FiniteInputValuesImplT(), 0.7f, s.getA1Input1(), s.getB1Input1(), s.getOptimalValueA().getFirst()));
        Objective obj2 = new ObjectiveImpl("Eficiencia energetica", calcInterval(new FiniteInputValuesImplC(), 0.7f, s.getA1Input2(), s.getB1Input2(), s.getOptimalValueA().getSecond()));

        this.getObjectives().add(obj1);
        this.getObjectives().add(obj2);
    }

    public List<ObjectiveImpl> getObjectivesImpl() {
        return this.getObjectives();
    }

    private List<Pair<Integer, Float>> calcInterval(FiniteInputValues<Integer> finiteValues, Float minMembDegree, Float a1, Float b1, Integer optimal) {
        HeytA<Float> algebra = new HeytAFloat();
        List<Pair<Integer, Float>> interval = new ArrayList<>();

        for (Integer fv1 : finiteValues.getFiniteList()) {
            Float f1 = algebra.meet(1.0f, algebra.join(0.0f, a1 - (b1 * Math.abs((fv1 * 0.1f) - (optimal * 0.1f)))));
            if (f1 >= minMembDegree) {
                interval.add(new Pair(fv1, f1));
            }
        }
        return interval;
    }

}
