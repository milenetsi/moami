/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package moamiappTC;

import LFuzzyLibrary.FiniteInputValues;
import LFuzzyLibrary.HeytA;
import LFuzzyLibrary.HeytAFloat;
import LFuzzyLibrary.Pair;
import java.util.ArrayList;
import java.util.List;
import moamiapp.Objective;

/**
 *
 * @author Milene
 */
public class ObjectiveImpl extends Objective<Float> {

    private List<Pair<Integer, Float>> intervaloAdequado;

    public ObjectiveImpl(String name, List<Pair<Integer, Float>> intervaloAdequado) {
        super(name);

        this.intervaloAdequado = intervaloAdequado;
    }

    public List<Pair<Integer, Float>> getIntervaloAdequado() {
        return intervaloAdequado;
    }
    
    
    

}
