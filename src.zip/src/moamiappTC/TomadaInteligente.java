/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package moamiappTC;

import LFuzzyLibrary.Sum;
import TemperatureConsumptionFC.DataHandler;
import TemperatureConsumptionFC.Settings;
import java.util.List;
import moamiapp.EventInternal;
import moamiapp.Item;
import moamiapp.Service;

/**
 *
 * @author Milene
 */
public class TomadaInteligente extends Item<TomadaInteligente> {

    private List<Item> Sensores;
    private Service<Sum> service;
    private DataHandler dh;

    public TomadaInteligente(String name, List<Item> Sensores, Settings s) {
        super(name);
        this.Sensores = Sensores;
        this.dh = new DataHandler(s);

        this.service = new Service<Sum>() {
            @Override
            public EventInternal executeService(Sum input) {

                boolean ok = false;
                if (input.getValue() instanceof Integer) {
                    Integer i = (Integer) input.getValue();
                    //Float newTemp = readTemperature() + ((i * 0.1f) * 0.6f);
                    //Integer newTemperature = Math.round(newTemp);

                    //<<AUMENTAR/REDUZIR TEMP DO AR. arduino
                    if (true) {//se mudou temp
                        ok = true;
                    }

                    System.out.println("Configuracao: " + (i * 0.1f) + " -> " + Math.round((i * 0.1f)));
                    //System.out.println("Nova temperatura: " + newTemperature);
                } else if (input.getValue().equals("AL")) {
                    //<< Aa  verifica ultima mofificacao: se reduziu:faz nada. Se nao:aumenta um grau
                    ok = true;
                    System.out.println("ALERT!!!!");
                } else {
                    ok = false;
                }

                if (ok) {
                    return new EventInternal<Boolean>("Configuracao alterada") {
                        @Override
                        public Boolean patternOfRecognition() {
                            System.out.println("Temperatura alterada!");
                            return true;
                        }

                        @Override
                        public Boolean isOn() {
                            return true;
                        }
                    };
                }
                System.out.println("Temperatura nao pode ser alterada!");
                return null;
            }
        };
    }

    //Service prove dado temp
    public Float readTemperature() {
        return dh.getTemperatureFromSensor();
    }

    //Service prove dado cons
    public Float readConsumption() {
        return dh.getConsumption();
    }

    public Service<Sum> getService() {
        return service;
    }

    public void setService(Service<Sum> service) {
        this.service = service;
    }

}
